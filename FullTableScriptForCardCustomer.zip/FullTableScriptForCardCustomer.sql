IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__CustomerC__statu__2C3393D0]') AND parent_object_id = OBJECT_ID(N'[dbo].[CustomerCard]'))
ALTER TABLE [dbo].[CustomerCard] DROP CONSTRAINT [FK__CustomerC__statu__2C3393D0]


GO



IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__CustomerC__Custo__2D27B809]') AND parent_object_id = OBJECT_ID(N'[dbo].[CustomerCard]'))
ALTER TABLE [dbo].[CustomerCard] DROP CONSTRAINT [FK__CustomerC__Custo__2D27B809]


GO



/****** Object:  Table [dbo].[CustomerStatus]    Script Date: 1/10/2022 11:07:57 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CustomerStatus]') AND type in (N'U'))
DROP TABLE [dbo].[CustomerStatus]


GO



/****** Object:  Table [dbo].[CustomerCard]    Script Date: 1/10/2022 11:07:57 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CustomerCard]') AND type in (N'U'))
DROP TABLE [dbo].[CustomerCard]


GO



/****** Object:  Table [dbo].[Customer]    Script Date: 1/10/2022 11:07:57 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Customer]') AND type in (N'U'))
DROP TABLE [dbo].[Customer]


GO



/****** Object:  Table [dbo].[Customer]    Script Date: 1/10/2022 11:07:57 AM ******/
SET ANSI_NULLS ON


GO



SET QUOTED_IDENTIFIER ON


GO



CREATE TABLE [dbo].[Customer](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO



/****** Object:  Table [dbo].[CustomerCard]    Script Date: 1/10/2022 11:07:57 AM ******/
SET ANSI_NULLS ON


GO



SET QUOTED_IDENTIFIER ON


GO



CREATE TABLE [dbo].[CustomerCard](
	[CardNo] [int] IDENTITY(1,1) NOT NULL,
	[ExpiryDate] [date] NULL,
	[statusId] [int] NULL,
	[AvailableBalance] [float] NULL,
	[IsActive] [tinyint] NULL,
	[Limit] [int] NULL,
	[CustomerId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[CardNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO



/****** Object:  Table [dbo].[CustomerStatus]    Script Date: 1/10/2022 11:07:57 AM ******/
SET ANSI_NULLS ON


GO



SET QUOTED_IDENTIFIER ON


GO



CREATE TABLE [dbo].[CustomerStatus](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](30) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO



ALTER TABLE [dbo].[CustomerCard]  WITH CHECK ADD FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customer] ([id])


GO



ALTER TABLE [dbo].[CustomerCard]  WITH CHECK ADD FOREIGN KEY([statusId])
REFERENCES [dbo].[CustomerStatus] ([id])


GO




